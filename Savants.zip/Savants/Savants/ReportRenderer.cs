﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Web;
namespace Savants
{
    public static class DictionaryExtension
    {
        public static string UrlEncode(this Dictionary<string, string> parameters)
        {
            return string.Join("&", parameters.Select(x => $"{x.Key}={WebUtility.UrlEncode(x.Value)}"));
        }

    }
    public class ReportRenderer
    {
      
        string exrvg = string.Empty;
        private CookieContainer _cookies = new CookieContainer();

        private readonly string _baseUrl;
        private readonly string _accessToken;

        public ReportRenderer(string baseUrl, string accessToken)
        {
            _baseUrl = baseUrl;
            _accessToken = accessToken;
        }

        private async Task<(string,string)> GetSession(string reportId)
        {
            var url = "/CRMReports/RSViewer/ReportViewer.aspx";//
            var data = new Dictionary<string, string>()
            {
                ["id"] = "{" + reportId + "}",
                ["iscustomreport"] = "true"
            };
            var response = Encoding.UTF8.GetString(await GetResponse(GetRequest("POST", url, data)));
            exrvg = response;
            var sessionId = response.Substring(response.LastIndexOf("ReportSession=") + 14, 24);
            var controlId = response.Substring(response.LastIndexOf("ControlID=") + 10, 32);
            return (sessionId, controlId);
        }

        public async Task<byte[]> Render(string reportId, string format, string filename)
        {
             var (sessionId, controlId) = await GetSession(reportId);
         
            var url = "/Reserved.ReportViewerWebControl.axd";
            var data = new Dictionary<string, string>()
            {
                ["OpType"] = "Export",
                ["Format"] = format,
                ["ContentDisposition"] = "AlwaysAttachment",
                ["FileName"] = filename,
                ["Culture"] = "1033",
                ["CultureOverrides"] = "True",
                ["UICulture"] = "1033",
                ["UICultureOverrides"] = "True",
                ["ReportSession"] = sessionId,
                ["ControlID"] = controlId
            };

             

             return await GetResponse(GetRequest("GET", $"{url}?{data.UrlEncode()}"));
            //return exrvg;
        }
       
        private HttpWebRequest GetRequest(string method, string url, Dictionary<string, string> data = null)
        {

            var request = WebRequest.CreateHttp($"{_baseUrl}{url}");
            request.Method = method;
            request.CookieContainer = _cookies;
            request.Headers.Add("Authorization", $"Bearer {_accessToken}");
            request.AutomaticDecompression = DecompressionMethods.GZip;
            try
            {
                if (data != null)
                {
                    var body = Encoding.ASCII.GetBytes(data.UrlEncode());

                    request.ContentType = "application/x-www-form-urlencoded";
                    request.ContentLength = body.Length;

                    using (var stream = request.GetRequestStream())
                    {
                        stream.Write(body, 0, body.Length);
                    }
                }
                return request;
            }
            catch(Exception ex)
            {
                exrvg += ex.ToString();
                return request;
            }
           
        }

        private async Task<byte[]> GetResponse(HttpWebRequest request)
        {
            using (var response = await request.GetResponseAsync() as HttpWebResponse)
            {
                using (var stream = response.GetResponseStream())
                using (var stream2 = new MemoryStream())
                {
                    await stream.CopyToAsync(stream2);
                    return stream2.ToArray();
                }
            }
        }
    }
}
