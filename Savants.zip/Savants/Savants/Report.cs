﻿using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;


namespace Savants
{
    public static class Report
    {
        [FunctionName("Report")]
        public static async Task<HttpResponseMessage> Run([HttpTrigger(AuthorizationLevel.Anonymous, "GET")]HttpRequestMessage req, TraceWriter log)
        {
            req.Headers.TryGetValues("X-MS-TOKEN-AAD-ACCESS-TOKEN", out var accessTokens);
            if (accessTokens != null)
            {

                var baseUrl = "https://march2018demo.crm.dynamics.com";
              
                var accessToken = accessTokens.FirstOrDefault();

                var queryString = req.GetQueryNameValuePairs();

                var reportId = queryString.FirstOrDefault(q => q.Key == "reportId").Value;
                var format = queryString.FirstOrDefault(q => q.Key == "format").Value;
                var filename = format == "PDF" ? "report.pdf" : "report.xls";
                var mimeType = format == "PDF" ? "application/pdf" : "application/vnd.ms-excel";
              
                var renderer = new ReportRenderer(baseUrl, accessToken);
                
                 var report = await renderer.Render(reportId, format, filename);
                var response = new HttpResponseMessage(HttpStatusCode.OK);
                response.Content = new ByteArrayContent(report);
                response.Content.Headers.ContentType = new MediaTypeHeaderValue(mimeType);
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentDisposition.FileName = filename;
                return response;
            }
            else
            {
                return req.CreateResponse(HttpStatusCode.BadRequest, "Access token not found.");
            }
        }
    }
}
